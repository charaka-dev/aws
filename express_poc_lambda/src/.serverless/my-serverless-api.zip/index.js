// import express from 'express';  //importing express module
// const apiApp = express();
// import loginRout from './routes/login_route.js'; //importing login route module


// apiApp.use(express.json()); // middleware to parse JSON request bodies

// apiApp.use('/api/', loginRout); //mounting login route at '/api/login' endpoint

// const port = 3000;
// apiApp.listen(port, () => {
//   console.log(`Server listening on port ${port}`);
// });
